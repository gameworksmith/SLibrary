//
//  SpeechTranscriberViewController.h
//  NUIdemo
//
//  Created by zhouguangdong on 2020/6/11.
//  Copyright © 2020 Alibaba idst. All rights reserved.
//

#ifndef SpeechTranscriberViewController_h
#define SpeechTranscriberViewController_h
#import <UIKit/UIKit.h>

//typedef enum {
//    kUnknowState,
//    kDidEnterBackground,
//    kWillEnterForeground,
//    kDidBecomeActive,
//} AppState;

@interface SpeechTranscriberViewController : UIViewController

//- (void)applicationState:(AppState)state;

- (void)terminateNui;
- (NSString*) genInitParams;
@end
#endif /* SpeechTranscriberViewController_h */
