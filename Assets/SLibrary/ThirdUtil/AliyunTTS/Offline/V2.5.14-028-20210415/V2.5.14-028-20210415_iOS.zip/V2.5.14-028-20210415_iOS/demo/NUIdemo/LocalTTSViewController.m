//
//  LocalTTSViewController.mm
//  NUIdemo
//
//  Created by zhuiyin on 2020/11/30.
//  All rights reserved.
//

#import "nuisdk.framework/Headers/NeoNuiTts.h"
#import "LocalTTSViewController.h"
#import "HWOptionButton.h"
#import "NuiSdkUtils.h"

#import <mach/mach.h>
#import <assert.h>
//#import <pthread.h>

#import "audio/NLSPlayAudio.h"
#import <AVFoundation/AVFoundation.h>
#import <AdSupport/ASIdentifierManager.h>

#ifdef DEBUG_TTS_DATA_SAVE
FILE * fp;
#endif

#define CPU_USAGE_INTERVAL 0.05
static LocalTTSViewController *myself = nil;
static NSString *myvoicedir = nil;
@interface LocalTTSViewController () <NlsPlayerDelegate, UITextFieldDelegate, HWOptionButtonDelegate, NeoNuiTtsDelegate> {
    IBOutlet UIButton *PlayButton;
    IBOutlet UIButton *TestButton;
    IBOutlet UIButton *PauseButton;
    IBOutlet UITextView *textViewContent;
    IBOutlet UITextView *instructionContent;

    IBOutlet UILabel *labelFontName;
    IBOutlet UILabel *labelSpeedLevel;
    IBOutlet UILabel *labelPitchLevel;
    IBOutlet UILabel *labelVolume;

    IBOutlet UITextField *textfieldSpeedLevel;
    IBOutlet UITextField *textfieldPitchLevel;
    IBOutlet UITextField *textfieldVolume;
    
    NSString * playingContent;
}

@property(nonatomic,strong) NeoNuiTts* nui;
@property(nonatomic, weak) HWOptionButton *fontName;
@property(nonatomic, weak) HWOptionButton *modeType;
@property(nonatomic,strong) NLSPlayAudio *voicePlayer;
@property(nonatomic,strong) NuiSdkUtils *utils;
@end

@implementation LocalTTSViewController

#define SCREEN_WIDTH_BASE 375
#define SCREEN_HEIGHT_BASE 667

static CGSize global_size;
static int loop_in = 0;
static BOOL loop_flag = NO;
static BOOL initialized = NO;

#pragma mark view controller methods

- (void)viewDidLoad {
    TLog(@"LocalTTSViewController did load");
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"本地语音合成";

    // Do any additional setup after loading the view.
    global_size = [UIScreen mainScreen].bounds.size;
    TLog(@"LocalTTSViewController-viewDidLoad mainScreen width=%f  height=%f",
          global_size.width, global_size.height);

    loop_in = TTS_EVENT_END;
    myself = self;
    
    [self InitView];
    // 注意：这里voiceplyer模块仅用于播放示例，未经过大规模线上测试
    _voicePlayer = [[NLSPlayAudio alloc] init];
    _voicePlayer.delegate = self;
    
    _utils = [NuiSdkUtils alloc];
    myvoicedir = [[NSString alloc] init];

    [self NuiTtsInit];
}

-(void)dealloc {
    TLog(@"%s",__FUNCTION__);
    [_voicePlayer cleanup];
    [_nui nui_tts_release];
    initialized = NO;
#ifdef DEBUG_TTS_DATA_SAVE
    if (fp) {
        fclose(fp);
    }
#endif
}

- (void)dismissKeyboard:(id)sender {
    [self.view endEditing:YES];
}

-(void)viewDidAppear:(BOOL)animated {
    TLog(@"LocalTTSViewController-viewDidAppear");
    [super viewDidAppear:animated];
    [self InitView];
}

-(void)viewWillDisappear:(BOOL)animated {
    TLog(@"LocalTTSViewController-viewWillDisappear");
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(tts_test_loop:) object:testDataList];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Audio Player Delegate
-(void) playerDidFinish{
    //播放数据被实际播放完成后回调。
    TLog(@"playerDidFinish");
}

#pragma mark -private methods

-(NSString *)genInitParams {
    NSString *strResourcesBundle = [[NSBundle mainBundle] pathForResource:@"Resources" ofType:@"bundle"];
    NSString *bundlePath = [[NSBundle bundleWithPath:strResourcesBundle] resourcePath];
    NSString *id_string = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    NSString *debug_path = [_utils createDir];
    myvoicedir = debug_path;
    TLog(@"debug_path:%@", debug_path);
    NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
    
    [dictM setObject:bundlePath forKey:@"workspace"];
    // 切换为离线合成模式
    [dictM setObject:@"0" forKey:@"mode_type"];

    // 如果需要保存调试日志到文件，初始化的时候加入该字段；不要保存日志，该字段删除
    // 日志文件是追加的方式存储的，下次初始化时并不会将老日志冲掉重写
    // 另外，在开启保存日志文件时，可以动态的通过接口nui_tts_set_param将日志等级设置成最高值，保证日志不写入文件，等需要写入时再动态设置成较低的等级
    [dictM setObject:debug_path forKey:@"debug_path"];


    // 请参照阿里云官网获取鉴权信息获取配额
    // https://help.aliyun.com/document_detail/204186.html?spm=a2c4g.11186623.6.630.3dbc38ba9f27Vr
    // 如果配额已耗尽，请联系客户扩大配额
    // 如果合成失败，通常是由于鉴权失败，可以参照阿里云官网Q&A部分
    // (https://help.aliyun.com/document_detail/204191.html?spm=a2c4g.11186623.6.657.3cde7340qMll1h)，根据错误日志判别导致鉴权失败的原因
    [dictM setObject:@"xx" forKey:@"ak_id"];
    [dictM setObject:@"xx" forKey:@"ak_secret"];
    [dictM setObject:@"xx" forKey:@"app_key"];
    [dictM setObject:@"software_nls_tts_offline" forKey:@"sdk_code"];

    // deviceid作为设备的唯一标识（可以是Mac地址，cpu序列号等参数），是进行鉴权认证的必要信息
    [dictM setObject:id_string forKey:@"device_id"];
    
    NSData *data = [NSJSONSerialization dataWithJSONObject:dictM options:NSJSONWritingPrettyPrinted error:nil];
    NSString * jsonStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    return jsonStr;
}

- (void)NuiTtsInit {
    if (_nui == NULL) {
        _nui = [NeoNuiTts get_instance];
        _nui.delegate = self;
    }
    NSString * initParam = [self genInitParams];

    // 初始化:需要特别注意该函数并没有加载语音包
    int retcode = [_nui nui_tts_initialize:[initParam UTF8String] logLevel:LOG_LEVEL_VERBOSE saveLog:YES];
    if (retcode != 0) {
        const char *errmsg = [_nui nui_tts_get_param: "error_msg"];
        TLog(@"init failed.retcode:%d.errmsg:%s", retcode, errmsg);
        return;
    }
    initialized = YES;
    // 加载语音包：已购买下载的语音包，可以放在任意位置，以aicheng为例，该语音包位于Documents/voices/下，设置命令为“Documents/voices/aicheng”
    // 语音包下载地址：https://help.aliyun.com/document_detail/204185.html?spm=a2c4g.11186623.6.628.3cde73409gZCmA
    // 请确保账号拥有使用该语音包的权限，如果没有购买是无法正常使用的。
    NSString *cmd = [NSString stringWithFormat:@"%@/aicheng", myvoicedir];
    retcode = [self.nui nui_tts_set_param:"extend_font_name" value:[cmd UTF8String]];
    // 必须保证语音包设置正确才能正常合成
    if (retcode != SUCCESS) {
        TLog(@"set(%@) failed.", cmd);
        return;
    }
#ifdef DEBUG_TTS_DATA_SAVE
    NSString *sp = self.createDir;
    const char* savePath = [sp UTF8String];

    if (fp == nullptr) {
        NSString *debug_file = [NSString stringWithFormat:@"%@/tts_dump.pcm", sp];
        fp = fopen([debug_file UTF8String], "w");
    }
#endif
}

-(void)InitView {
    // init Button
    [self setButton];
    // init TextView
    [self setTextView];
    // init Label
    [self setLabel];
    // init OptionButton
    [self setOptionButton];
    // init TextField
    [self setTextField];
    // init setInstruction
    [self setInstruction];
}

- (void)setButton {
    // 基于iPhone6s开发测试demo
    CGFloat button_width = global_size.width/SCREEN_WIDTH_BASE * 80;
    CGFloat button_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat x = global_size.width/SCREEN_WIDTH_BASE * 27.5;
    CGFloat y = global_size.height/SCREEN_HEIGHT_BASE * 65;
    
    PlayButton = [UIButton buttonWithType:UIButtonTypeCustom];
    PlayButton.frame = CGRectMake(x, y, button_width, button_height);
    UIImage *image = [UIImage imageNamed:@"button_start"];
    [PlayButton setBackgroundImage:image forState:UIControlStateNormal];
    [PlayButton setTitle:@"播放" forState:UIControlStateNormal];
    [PlayButton setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    PlayButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [PlayButton addTarget:self action:@selector(startTTS:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:PlayButton];

    // ---- TestButton ---
    CGFloat TestButton_width = global_size.width/SCREEN_WIDTH_BASE * 80;
    CGFloat TestButton_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat TestButton_x = global_size.width/SCREEN_WIDTH_BASE * (SCREEN_WIDTH_BASE - 27.5 - 80);
    CGFloat TestButton_y = global_size.height/SCREEN_HEIGHT_BASE * 65;
    
    TestButton = [UIButton buttonWithType:UIButtonTypeCustom];
    TestButton.frame = CGRectMake(TestButton_x, TestButton_y, TestButton_width, TestButton_height);
    UIImage *TestButton_image = [UIImage imageNamed:@"button_start"];
    [TestButton setBackgroundImage:TestButton_image forState:UIControlStateNormal];
    [TestButton setTitle:@"测试" forState:UIControlStateNormal];
    [TestButton setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    TestButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [TestButton addTarget:self action:@selector(startTest:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:TestButton];

    // ---- PauseButton ---
    CGFloat PauseButton_width = global_size.width/SCREEN_WIDTH_BASE * 80;
    CGFloat PauseButton_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat PauseButton_x = (global_size.width - PauseButton_width)/2;
    CGFloat PauseButton_y = global_size.height/SCREEN_HEIGHT_BASE * 65;
    
    PauseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    PauseButton.frame = CGRectMake(PauseButton_x, PauseButton_y, PauseButton_width, PauseButton_height);
    UIImage *PauseButton_image = [UIImage imageNamed:@"button_start"];
    [PauseButton setBackgroundImage:PauseButton_image forState:UIControlStateNormal];
    [PauseButton setTitle:@"暂停" forState:UIControlStateNormal];
    [PauseButton setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    PauseButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [PauseButton addTarget:self action:@selector(pauseTTS:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:PauseButton];
}

- (void)setTextView {
    // 基于iPhone6s开发测试demo
    // ---- textViewContent ---
    CGFloat textViewContent_width = global_size.width/SCREEN_WIDTH_BASE * 320;
    CGFloat textViewContent_height = global_size.height/SCREEN_HEIGHT_BASE * 220;
    CGFloat textViewContent_x = global_size.width/2 - textViewContent_width/2;
    CGFloat textViewContent_y = global_size.height/SCREEN_HEIGHT_BASE * 80 + global_size.height/SCREEN_HEIGHT_BASE * 30;
    
    CGRect textViewContent_rect = CGRectMake(textViewContent_x, textViewContent_y, textViewContent_width, textViewContent_height);
    if (!textViewContent) {
        textViewContent = [[UITextView alloc] initWithFrame:textViewContent_rect];
    }
    textViewContent.layer.borderWidth = 0.6;
    textViewContent.layer.borderColor = [UIColor blackColor].CGColor;
    textViewContent.layer.cornerRadius = 10;
    [textViewContent setBackgroundColor: [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:0.1]];
    textViewContent.scrollEnabled = YES;

    textViewContent.text = @"语音合成服务，通过先进的深度学习技术，将文本转换成自然流畅的语音。目前有多种音色可供选择，并提供调节语速、语调、音量等功能。适用于智能客服、语音交互、文学有声阅读和无障碍播报等场景。";
    textViewContent.textColor = [UIColor darkGrayColor];
    textViewContent.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:textViewContent];
}

- (void)setLabel {
    // ---- labelFontName ---
    CGFloat labelFontName_width = global_size.width/SCREEN_WIDTH_BASE * 180;
    CGFloat labelFontName_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat labelFontName_x = global_size.width/SCREEN_WIDTH_BASE * 27.5;
    CGFloat labelFontName_y = global_size.height/SCREEN_HEIGHT_BASE * (315 + 15);

    CGRect labelFontName_rect = CGRectMake(labelFontName_x, labelFontName_y, labelFontName_width, labelFontName_height);
    labelFontName = [[UILabel alloc] initWithFrame:labelFontName_rect];
    labelFontName.text = @"font name:";
    labelFontName.font = [UIFont boldSystemFontOfSize:15];
    [self.view addSubview:labelFontName];

    // ---- labelSpeedLevel ---
    CGFloat labelSpeedLevel_width = global_size.width/SCREEN_WIDTH_BASE * 180;
    CGFloat labelSpeedLevel_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat labelSpeedLevel_x = global_size.width/SCREEN_WIDTH_BASE * 27.5;
    CGFloat labelSpeedLevel_y = global_size.height/SCREEN_HEIGHT_BASE * (355 + 15);

    CGRect labelSpeedLevel_rect = CGRectMake(labelSpeedLevel_x, labelSpeedLevel_y, labelSpeedLevel_width, labelSpeedLevel_height);
    labelSpeedLevel = [[UILabel alloc] initWithFrame:labelSpeedLevel_rect];
    labelSpeedLevel.text = @"speed level:";
    labelSpeedLevel.font = [UIFont boldSystemFontOfSize:15];
    [self.view addSubview:labelSpeedLevel];

    // ---- labelPitchLevel ---
    CGFloat labelPitchLevel_width = global_size.width/SCREEN_WIDTH_BASE * 180;
    CGFloat labelPitchLevel_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat labelPitchLevel_x = global_size.width/SCREEN_WIDTH_BASE * 27.5;
    CGFloat labelPitchLevel_y = global_size.height/SCREEN_HEIGHT_BASE * (395 + 15);

    CGRect labelPitchLevel_rect = CGRectMake(labelPitchLevel_x, labelPitchLevel_y, labelPitchLevel_width, labelPitchLevel_height);
    labelPitchLevel = [[UILabel alloc] initWithFrame:labelPitchLevel_rect];
    labelPitchLevel.text = @"pitch level:";
    labelPitchLevel.font = [UIFont boldSystemFontOfSize:15];
    [self.view addSubview:labelPitchLevel];

    // ---- labelVolume ---
    CGFloat labelVolume_width = global_size.width/SCREEN_WIDTH_BASE * 180;
    CGFloat labelVolume_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat labelVolume_x = global_size.width/SCREEN_WIDTH_BASE * 27.5;
    CGFloat labelVolume_y = global_size.height/SCREEN_HEIGHT_BASE * (435 + 15);

    CGRect labelVolume_rect = CGRectMake(labelVolume_x, labelVolume_y, labelVolume_width, labelVolume_height);
    labelVolume = [[UILabel alloc] initWithFrame:labelVolume_rect];
    labelVolume.text = @"volume:";
    labelVolume.font = [UIFont boldSystemFontOfSize:15];
    [self.view addSubview:labelVolume];
    

}

- (void)setInstruction {
    TLog(@"setInstruction");
    // ---- instruction ---
    CGFloat instructionViewContent_width = global_size.width/SCREEN_WIDTH_BASE * 340;
    CGFloat instructionViewContent_height = global_size.height/SCREEN_HEIGHT_BASE * 160;
    CGFloat instructionViewContent_x = global_size.width/2 - instructionViewContent_width/2;
    CGFloat instructionViewContent_y = 530;

    CGRect instruction_rect = CGRectMake(instructionViewContent_x, instructionViewContent_y, instructionViewContent_width, instructionViewContent_height);
    if (!instructionContent) {
        instructionContent = [[UITextView alloc] initWithFrame:instruction_rect];
    }
    instructionContent.layer.borderWidth = 0.6;
    instructionContent.layer.borderColor = [UIColor blackColor].CGColor;
    instructionContent.layer.cornerRadius = 10;
    [instructionContent setBackgroundColor: [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:0.1]];
    instructionContent.scrollEnabled = YES;

    instructionContent.text = @"说明：1)demo需要在函数genInitParams设置鉴权信息；2)SDK和语音包是隔离的，使用前先将下载的语音包推到应用沙盒路径/Documents/voices目录下，点击‘请选择’按钮选择语音包，否则切换失败将使用原语音包进行合成；";
    instructionContent.textColor = [UIColor darkGrayColor];
    instructionContent.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:instructionContent];
}
- (void)setTextField {
    // ---- textfieldSpeedLevel ---
    CGFloat textfieldSpeedLevel_width = global_size.width/SCREEN_WIDTH_BASE * 110;
    CGFloat textfieldSpeedLevel_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat textfieldSpeedLevel_x = global_size.width/SCREEN_WIDTH_BASE * 210;
    CGFloat textfieldSpeedLevel_y = global_size.height/SCREEN_HEIGHT_BASE * (355 + 15);

    CGRect textfieldSpeedLevel_rect = CGRectMake(textfieldSpeedLevel_x, textfieldSpeedLevel_y, textfieldSpeedLevel_width, textfieldSpeedLevel_height);
    textfieldSpeedLevel = [[UITextField alloc] initWithFrame:textfieldSpeedLevel_rect];
    textfieldSpeedLevel.borderStyle = UITextBorderStyleRoundedRect;
    textfieldSpeedLevel.font = [UIFont fontWithName:@"Arial" size:15];
    textfieldSpeedLevel.userInteractionEnabled = YES;
    [self.view addSubview:textfieldSpeedLevel];

    // ---- textfieldPitchLevel ---
    CGFloat textfieldPitchLevel_width = global_size.width/SCREEN_WIDTH_BASE * 110;
    CGFloat textfieldPitchLevel_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat textfieldPitchLevel_x = global_size.width/SCREEN_WIDTH_BASE * 210;
    CGFloat textfieldPitchLevel_y = global_size.height/SCREEN_HEIGHT_BASE * (395 + 15);

    CGRect textfieldPitchLevel_rect = CGRectMake(textfieldPitchLevel_x, textfieldPitchLevel_y, textfieldPitchLevel_width, textfieldPitchLevel_height);
    textfieldPitchLevel = [[UITextField alloc] initWithFrame:textfieldPitchLevel_rect];
    textfieldPitchLevel.borderStyle = UITextBorderStyleRoundedRect;
    textfieldPitchLevel.font = [UIFont fontWithName:@"Arial" size:15];
    textfieldPitchLevel.userInteractionEnabled = YES;
    [self.view addSubview:textfieldPitchLevel];

    // ---- textfieldVolume ---
    CGFloat textfieldVolume_width = global_size.width/SCREEN_WIDTH_BASE * 110;
    CGFloat textfieldVolume_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat textfieldVolume_x = global_size.width/SCREEN_WIDTH_BASE * 210;
    CGFloat textfieldVolume_y = global_size.height/SCREEN_HEIGHT_BASE * (435 + 15);

    CGRect textfieldVolume_rect = CGRectMake(textfieldVolume_x, textfieldVolume_y, textfieldVolume_width, textfieldVolume_height);
    textfieldVolume = [[UITextField alloc] initWithFrame:textfieldVolume_rect];
    textfieldVolume.borderStyle = UITextBorderStyleRoundedRect;
    textfieldVolume.font = [UIFont fontWithName:@"Arial" size:15];
    textfieldVolume.userInteractionEnabled = YES;
    [self.view addSubview:textfieldVolume];
}

- (void)setOptionButton {
    // ---- fontName ---
    CGFloat fontName_width = global_size.width/SCREEN_WIDTH_BASE * 150;
    CGFloat fontName_height = global_size.height/SCREEN_HEIGHT_BASE * 40;
    CGFloat fontName_x = global_size.width/SCREEN_WIDTH_BASE * (SCREEN_WIDTH_BASE - 27.5 - 150);
    CGFloat fontName_y = global_size.height/SCREEN_HEIGHT_BASE * 95 + global_size.height/SCREEN_HEIGHT_BASE * 220 + global_size.height/SCREEN_HEIGHT_BASE * 15;

    HWOptionButton *fontNameBtn = [[HWOptionButton alloc] initWithFrame:CGRectMake(fontName_x, fontName_y, fontName_width, fontName_height)];

    fontNameBtn.array = @[@"xiaoyun", @"aijia", @"aicheng"];
    fontNameBtn.delegate = self;
    fontNameBtn.showSearchBar = YES;
    [self.view addSubview:fontNameBtn];
    self.fontName = fontNameBtn;

}

- (void)playTTS:(NSString *)content {
    playingContent = content;
    
    if (!self.nui) {
        TLog(@"nui tts not init");
        return;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        textViewContent.text = content;
        [self UpdateTtsParams];
        if (initialized) {
            [self.nui nui_tts_play:"1" taskId:"" text:[content UTF8String]];
        } else {
            TLog(@"It has not been initialized!!!");
        }
    });
}

-(void) UpdateTtsParams {
    if ([_fontName.title isEqualToString:@"-请选择-"]) {
        // DO NOTHING
        TLog(@"do nothing.请首先选择有效路径（如/Documents/voices）下的语音包");
    } else {
        // 切换语音包，如准备切换到aijia，aijia语音包位于Documents/voices/下，切换命令为“Documents/voices/aijia”
        NSString *cmd = [NSString stringWithFormat:@"%@/%@", myvoicedir, _fontName.title];
        int retcode = [self.nui nui_tts_set_param:"extend_font_name" value:[cmd UTF8String]];
        if (retcode != SUCCESS) {
            TLog(@"switch(%@) failed, continue to use the original voice", cmd);
        }
        initialized = YES;
    }
    if (self->textfieldSpeedLevel.text.length > 0) {
        // 设置语速，默认1.0
        [self.nui nui_tts_set_param:"speed_level" value:[textfieldSpeedLevel.text UTF8String]];
    }
    if (self->textfieldPitchLevel.text.length > 0) {
        // 设置音调，默认0
        [self.nui nui_tts_set_param:"pitch_level" value:[textfieldPitchLevel.text UTF8String]];
    }
    if (self->textfieldVolume.text.length > 0) {
        // 设置音量，默认1.0
        [self.nui nui_tts_set_param:"volume" value:[textfieldVolume.text UTF8String]];
    }
}

static NSArray *testDataList = nil;
- (void)tts_test_loop:(NSArray<NSString *>*)list {
    static int i = 0;
    if (!list || i >= list.count) {
        TLog(@"tts test loop finish or list = nil");
        return;
    }
    
    if (loop_in == TTS_EVENT_START) {
        [self performSelector:@selector(tts_test_loop:) withObject:list afterDelay:3];
        return ;
    }
    
    if (loop_in == TTS_EVENT_CANCEL ||
        loop_in == TTS_EVENT_ERROR) {
        TLog(@"Tts canceled or Error");
        return ;
    }
    
    NSString * dialog = list[i];
    [self playTTS:dialog];
    i++;
    
    [self performSelector:@selector(tts_test_loop:) withObject:list afterDelay:3];
}

#pragma mark - Button Action
- (IBAction)startTTS:(UIButton *)sender {
    playingContent = textViewContent.text;
    if (!self.nui) {
        TLog(@"tts not init");
        return;
    }
    
    NSString *content = textViewContent.text;
    dispatch_async(dispatch_get_main_queue(), ^{ 
        [self UpdateTtsParams];
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker error:nil];
        if (initialized) {
            [self.nui nui_tts_play:"1" taskId:"" text:[content UTF8String]];
        } else {
            TLog(@"It has not been initialized!!!");
        }
    });

    dispatch_async(dispatch_get_main_queue(), ^{
        UIImage *image = [UIImage imageNamed:@"button_stop"];
        [PlayButton setBackgroundImage:image forState:UIControlStateNormal];
        [PlayButton setTitle:@"停止" forState:UIControlStateNormal];
        [PlayButton removeTarget:self action:@selector(startTTS:) forControlEvents:UIControlEventTouchUpInside];
        [PlayButton addTarget:self action:@selector(stopTTS:) forControlEvents:UIControlEventTouchUpInside];
    });
}

- (IBAction)stopTTS:(UIButton *)sender {
    if (_nui != nil) {
        TLog(@"LocalTTSViewController stop tts");

        dispatch_async(dispatch_get_main_queue(), ^{
            [self.nui nui_tts_cancel:NULL];
            [self->_voicePlayer stop];
        });
        
        dispatch_async(dispatch_get_main_queue(), ^{
            // UI更新代码
            UIImage *image = [UIImage imageNamed:@"button_start"];
            [PlayButton setBackgroundImage:image forState:UIControlStateNormal];
            [PlayButton setTitle:@"播放" forState:UIControlStateNormal];
            [PlayButton removeTarget:self action:@selector(stopTTS:) forControlEvents:UIControlEventTouchUpInside];
            [PlayButton addTarget:self action:@selector(startTTS:) forControlEvents:UIControlEventTouchUpInside];
            
            [PauseButton setBackgroundImage:image forState:UIControlStateNormal];
            [PauseButton setTitle:@"暂停" forState:UIControlStateNormal];
            [PauseButton removeTarget:self action:@selector(resumeTTS:) forControlEvents:UIControlEventTouchUpInside];
            [PauseButton addTarget:self action:@selector(pauseTTS:) forControlEvents:UIControlEventTouchUpInside];
        });
    } else {
        TLog(@"in stopTTS, _nui == nil.");
    }
}


- (IBAction)pauseTTS:(UIButton *)sender {
    if (_nui != nil) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.nui nui_tts_pause];
            [self.voicePlayer pause];
            // UI更新代码
            UIImage *image = [UIImage imageNamed:@"button_stop"];
            [PauseButton setBackgroundImage:image forState:UIControlStateNormal];
            [PauseButton setTitle:@"继续" forState:UIControlStateNormal];
            [PauseButton removeTarget:self action:@selector(pauseTTS:) forControlEvents:UIControlEventTouchUpInside];
            [PauseButton addTarget:self action:@selector(resumeTTS:) forControlEvents:UIControlEventTouchUpInside];
        });
    } else {
        TLog(@"in pauseTTS, _nui == nil.");
    }
}

- (IBAction)resumeTTS:(UIButton *)sender {
    if (_nui != nil) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.nui nui_tts_resume];
            [self.voicePlayer resume];
            // UI更新代码
            UIImage *image = [UIImage imageNamed:@"button_start"];
            [PauseButton setBackgroundImage:image forState:UIControlStateNormal];
            [PauseButton setTitle:@"暂停" forState:UIControlStateNormal];
            [PauseButton removeTarget:self action:@selector(resumeTTS:) forControlEvents:UIControlEventTouchUpInside];
            [PauseButton addTarget:self action:@selector(pauseTTS:) forControlEvents:UIControlEventTouchUpInside];
        });
    } else {
        TLog(@"in resumeTTS, _nui == nil.");
    }
}


- (IBAction)startTest:(UIButton *)sender {
    TLog(@"start a pthread for tts test.");
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(tts_test_loop:) object:testDataList];

    if (!self.nui) {
        TLog(@"nui tts not init");
    }
    
    loop_flag = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImage *image = [UIImage imageNamed:@"button_stop"];
        [TestButton setBackgroundImage:image forState:UIControlStateNormal];
        [TestButton setTitle:@"结束" forState:UIControlStateNormal];
        [TestButton removeTarget:self action:@selector(startTest:) forControlEvents:UIControlEventTouchUpInside];
        [TestButton addTarget:self action:@selector(stopTest:) forControlEvents:UIControlEventTouchUpInside];
    });
    
    
    if (!testDataList) {
        TLog(@"get test list");
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"thirdparty/test" ofType:@"txt"];
        NSString *dataFile = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
        testDataList = [dataFile componentsSeparatedByString:@"\n"];
    }

    [self tts_test_loop:testDataList];
    return;
}

- (IBAction)stopTest:(UIButton *)sender {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(tts_test_loop:) object:testDataList];
    
    if (_nui != nil) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [_nui nui_tts_cancel:NULL];
        });
        loop_flag = NO;
        loop_in = TTS_EVENT_END;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            // UI更新代码
            UIImage *image = [UIImage imageNamed:@"button_start"];
            [TestButton setBackgroundImage:image forState:UIControlStateNormal];
            [TestButton setTitle:@"测试" forState:UIControlStateNormal];
            [TestButton removeTarget:self action:@selector(stopTest:) forControlEvents:UIControlEventTouchUpInside];
            [TestButton addTarget:self action:@selector(startTest:) forControlEvents:UIControlEventTouchUpInside];
        });
    } else {
        TLog(@"in stopTest, _nui == nil.");
    }
}


#pragma mark - tts callback
- (void)onNuiTtsEventCallback:(NuiSdkTtsEvent)event taskId:(char*)taskid code:(int)code {
    TLog(@"onNuiTtsEventCallback event[%d]", event);
    if (event == TTS_EVENT_START) {
        loop_in = TTS_EVENT_START;
        // 确保开始播放下一次任务前，清空缓存数据
        [self->_voicePlayer stop];
        // 测试发现“播放”和“停止”切换非常快的时候（如点完播放，立即点停止），虽然事件TTS_EVENT_START比TTS_EVENT_END早，因为dispatch_async是异步的
        // _voicePlayer play线程的启动却可能比stop更晚，因此这里同步重置voicePlayer状态
        [self->_voicePlayer setstate:(PlayerState)playing];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self->_voicePlayer play];
        });
    } else if (event == TTS_EVENT_END || event == TTS_EVENT_CANCEL || event == TTS_EVENT_ERROR) {
        loop_in = event;
        if (event == TTS_EVENT_END) {
            // 注意这里是指语音合成完成，而非播放完成，播放完成需要由voicePlayer对象来进行通知
            [self->_voicePlayer drain];
        } else {
            // 取消播报、或者发生异常时终止播放
            [self->_voicePlayer setstate:(PlayerState)stopped];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.nui nui_tts_cancel:NULL];
                [self->_voicePlayer stop];
            });
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            // UI更新代码
            UIImage *image = [UIImage imageNamed:@"button_start"];
            [PlayButton setBackgroundImage:image forState:UIControlStateNormal];
            [PlayButton setTitle:@"播放" forState:UIControlStateNormal];
            [PlayButton removeTarget:self action:@selector(stopTTS:) forControlEvents:UIControlEventTouchUpInside];
            [PlayButton addTarget:self action:@selector(startTTS:) forControlEvents:UIControlEventTouchUpInside];
        });
    }
}

- (void)onNuiTtsUserdataCallback:(char*)info infoLen:(int)info_len buffer:(char*)buffer len:(int)len taskId:(char*)task_id {
    TLog(@"onnuiTtsUserdataCallback info text %s index %d.len:%d", info, info_len, len);
    if (len > 0) {
        [_voicePlayer write:(char*)buffer Length:(unsigned int)len];
    }
}

-(void)onNuiTtsVolumeCallback:(int)volume taskId:(char*)task_id {
    ;
}

@end
