//
//  LocalSpeechRecognizerViewController.h
//  NUIdemo
//
//  Created by zhouguangdong on 2020/9/6.
//  Copyright © 2020 Alibaba idst. All rights reserved.
//

#ifndef LocalSpeechRecognizerViewController_h
#define LocalSpeechRecognizerViewController_h

#import <UIKit/UIKit.h>

@interface LocalSpeechRecognizerViewController : UIViewController

- (void)terminateNui;
- (NSString*) genInitParams;
@end

#endif /* LocalSpeechRecognizerViewController_h */
