//
//  FileTranscriberViewController.h
//  NUIdemo
//
//  Created by zhouguangdong on 2020/8/22.
//  Copyright © 2020 Alibaba idst. All rights reserved.
//

#ifndef FileTranscriberViewController_h
#define FileTranscriberViewController_h

#import <UIKit/UIKit.h>

@interface FileTranscriberViewController : UIViewController

- (void)terminateNui;
- (NSString*) genInitParams;
- (NSString*) genStartParams;
@end
#endif /* FileTranscriberViewController_h */
