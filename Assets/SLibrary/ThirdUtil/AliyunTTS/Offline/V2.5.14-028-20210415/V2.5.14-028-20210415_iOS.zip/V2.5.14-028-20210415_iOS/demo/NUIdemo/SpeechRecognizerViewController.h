//
//  SpeechRecognizerViewController.h
//  NUIdemo
//
//  Created by zhouguangdong on 2020/6/11.
//  Copyright © 2020 Alibaba idst. All rights reserved.
//

#ifndef SpeechRecognizerViewController_h
#define SpeechRecognizerViewController_h

#import <UIKit/UIKit.h>

//typedef enum {
//    kUnknowState,
//    kDidEnterBackground,
//    kWillEnterForeground,
//    kDidBecomeActive,
//} AppState;

@interface SpeechRecognizerViewController : UIViewController

//- (void)applicationState:(AppState)state;

- (void)terminateNui;
- (NSString*) genInitParams;
@end
#endif /* SpeechRecognizerViewController_h */
