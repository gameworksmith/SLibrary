//
//  WakeupAndSpeechRecognizerViewController.h
//  NUIdemo
//
//  Created by zhouguangdong on 2020/7/29.
//  Copyright © 2020 Alibaba idst. All rights reserved.
//

#ifndef WakeupAndSpeechRecognizerViewController_h
#define WakeupAndSpeechRecognizerViewController_h
#import <UIKit/UIKit.h>
@interface WakeupAndSpeechRecognizerViewController : UIViewController

//- (void)applicationState:(AppState)state;

- (void)terminateNui;
- (NSString*) genInitParams;
@end
#endif /* WakeupAndSpeechRecognizerViewController_h */
