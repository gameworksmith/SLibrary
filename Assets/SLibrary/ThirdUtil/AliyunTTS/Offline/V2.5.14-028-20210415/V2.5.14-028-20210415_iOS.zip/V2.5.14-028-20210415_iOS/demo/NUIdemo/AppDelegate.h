//
//  AppDelegate.h
//  NUIdemo
//
//  Created by 傅世忱 on 2018/7/3.
//  Copyright © 2018年 傅世忱. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

