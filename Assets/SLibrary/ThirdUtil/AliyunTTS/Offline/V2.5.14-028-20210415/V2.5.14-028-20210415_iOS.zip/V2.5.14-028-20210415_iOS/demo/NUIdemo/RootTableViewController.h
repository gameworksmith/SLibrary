//
//  RootTableViewController.h
//  NUIdemo
//
//  Created by huanwh on 2018/12/25.
//  Copyright © 2018 Alibaba idst. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RootTableViewController : UITableViewController
-(void) setupButton:(UIButton*)button
                    index:(int)index
                    title:(NSString*)title
                    action:(SEL)action;
@end

NS_ASSUME_NONNULL_END
