//
//  main.m
//  NUIdemo
//
//  Created by jiang on 2017/3/9.
//  Copyright © 2017年 skydrui.regular. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "CrashReporter.h"
//#define OPEN_CRASH_REPORTER
int main(int argc, char * argv[]) {
    @autoreleasepool {
#ifdef OPEN_CRASH_REPORTER
        enable_crash_reporter_service();
#endif
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
