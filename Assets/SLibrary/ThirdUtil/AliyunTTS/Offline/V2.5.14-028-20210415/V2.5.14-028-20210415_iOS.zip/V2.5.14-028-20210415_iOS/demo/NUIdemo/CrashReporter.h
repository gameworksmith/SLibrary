//
//  CrashReporter.h
//  CrashReporter-plcrashreporter
//
//  Created by 谈Xx on 17/2/8.
//  Copyright © 2017年 谈Xx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CrashReporter : NSObject

/**
 *  启动CrashReporter服务
 */
void enable_crash_reporter_service (void);
    
@end
