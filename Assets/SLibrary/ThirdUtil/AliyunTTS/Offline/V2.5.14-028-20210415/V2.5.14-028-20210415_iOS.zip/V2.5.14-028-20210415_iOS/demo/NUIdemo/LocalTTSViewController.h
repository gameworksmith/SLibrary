//
//  TTSLocalViewController.h
//  NUIdemo
//
//  Created by zhuiyin on 2020/11/30.
//  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocalTTSViewController : UIViewController

@end
