//
//  NuiCfg.h
//  NUIdemo
//
//  Created by zhouguangdong on 2019/12/29.
//  Copyright © 2019 Alibaba idst. All rights reserved.
//

#ifndef NuiCfg_h
#define NuiCfg_h

#define SDK_NUI
#define SDK_TTS
#define SDK_FILE_TRANS
//#define SDK_LOCAL_ASR
#endif /* NuiCfg_h */
